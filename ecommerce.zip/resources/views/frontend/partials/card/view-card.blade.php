@extends('frontend.master.master')
@section('title')
    Cart Page
@endsection
@section('content')
    @livewire('frontend.view-card')
@endsection
