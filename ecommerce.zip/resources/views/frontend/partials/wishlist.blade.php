@extends('frontend.master.master')
@section('title')
    Wishlist
@endsection
@section('content')
    @livewire('frontend.wishlist')
@endsection
