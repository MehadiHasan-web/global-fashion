@extends('frontend.master.master')
@section('title')
    Shop
@endsection
@section('content')
    @livewire('frontend.shop')
@endsection
