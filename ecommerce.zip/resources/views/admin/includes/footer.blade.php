<footer class="main-footer fixed-btm">
    &copy; 2023 Xcode Company
</footer>
