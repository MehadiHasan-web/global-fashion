@extends('admin.master.master');
@section('title')
    Order
@endsection
@section('subtitle')
    New Order List
@endsection
@section('content')
    @livewire('admin.order-menegment')
@endsection
