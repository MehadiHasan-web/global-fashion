@extends('admin.master.master');
@section('title')
    Order received
@endsection
@section('subtitle')
    Order received List
@endsection
@section('content')
    @livewire('admin.order-received')
@endsection
